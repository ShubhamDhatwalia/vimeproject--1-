// // import React from 'react';
// // import videosData from '../data/videos.json';

// // const VideoDisplay = () => {
// //   return (
// //     <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-8">
// //       {videosData.videos.map(video => (
// //         <div key={video.id} className="mb-8 md:mb-0">
// //           <div className="bg-white w-96 h-96 rounded-md shadow-md">
// //             <div className="mb-4" style={{ width: '100%' }}>
// //               <video width="100%" height="240" controls className="mb-2">
// //                 <source src="./.." type="video/mp4" />
// //                 Your browser does not support the video tag.
// //               </video>
// //             </div>
// //             <div>
// //               <h2 className="text-xl font-bold">{video.title}</h2>
// //               <h3 className="text-lg">{video.singer}</h3>
// //             </div>
// //           </div>
// //         </div>
// //       ))}
// //     </div>
    
// //   );
// // };

// // export default VideoDisplay;

// import React, { useState, useEffect } from 'react';

// const VideoDisplay = () => {
//   const [videos, setVideos] = useState([]);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     fetch('/public/data/videos.json') // Update the path accordingly
//       .then((response) => {
//         if (!response.ok) {
//           throw new Error(`Failed to fetch videos (HTTP ${response.status})`);
//         }
//         return response.json();
//       })
//       .then((data) => setVideos(data))
//       .catch((error) => {
//         console.error('Error fetching videos:', error);
//         setError(error.message);
//       });
//   }, []);

//   if (error) {
//     return <div>Error fetching videos: {error}</div>;
//   }

//   return (
//     <div className="grid grid-cols-3 gap-4 mt-8">
//       {videos.map((video) => (
//         <div key={video.id} className="relative group">
//           <video
//             controls
//             className="w-full h-32 object-cover rounded-md transition duration-300 transform group-hover:scale-110"
//           >
//             <source src={`/Videos/${video.url}`} type="video/mp4" />
//             Your browser does not support the video tag.
//           </video>
//           <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300">
//             <h3 className="text-white">{video.title}</h3>
//           </div>
//         </div>
//       ))}
//     </div>
//   );
// };

// export default VideoDisplay;





