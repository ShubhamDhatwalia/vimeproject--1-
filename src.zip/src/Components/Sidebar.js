

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { GiHamburgerMenu } from "react-icons/gi";
import { MdClose } from "react-icons/md";
import VideoDisplay from './VideoList';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const onToggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>



 

      <section>
        <div className='grid grid-cols-2'>
         <div>
         <div className={`bg-white shadow shadow-gray-900 mt-[77px] h-screen w-64 fixed top-0 left-0 transition-transform transform ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-4">
          <button onClick={onToggleSidebar} className="text-black relative left-52 text-2xl">
            {isOpen ? <MdClose /> : null}
          </button>
          <h2 className="text-white">Sidebar</h2>
          <ul className="mt-4">
            <li className='mt-4'>
              <Link to="/">Home</Link>
            </li>
            <li className='mt-4'>
              <Link to="/library">Library</Link>
            </li>
            <li className='mt-4'>
              <Link to="/live-events">Live Events</Link>
            </li>
          </ul>
        </div>
        <hr className="border-t border-gray-700" />
        <div className="p-4">
          <h2 className="text-white">More Options</h2>
          <ul className="mt-4">
            <li className='mt-4'>
              <Link to="/showcases">Showcases</Link>
            </li>
            <li className='mt-4'>
              <Link to="/analytics">Analytics</Link>
            </li>
            <li className='mt-4'>
              <Link to="/monetize">Monetize</Link>
            </li>
          </ul>
        </div>
      </div>

      <div
        className={`fixed top-4 left-4 cursor-pointer ${isOpen ? 'hidden' : ''}`}
        onClick={onToggleSidebar}
      >
         <h1 className='mt-20 text-gray-400 text-4xl'> 
           <GiHamburgerMenu />
           </h1>
        
      </div>
         </div>
         
         
         <div>
         <VideoDisplay/>
         </div>
        </div>
      </section>

    </>
  );
};

export default Sidebar;
