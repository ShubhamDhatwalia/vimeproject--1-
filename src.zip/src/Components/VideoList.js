import React from 'react';
import videosData from '../data/videos.json';

const VideoDisplay = () => {
  return (
    <div className="mt-12">
      {videosData.videos.map(video => (
        <div key={video.id} className="mb-8">
          <div className="flex justify-center items-center">
            <h2 className="text-xl font-bold mr-4">{video.title}</h2>
            <h3 className="text-lg">{video.singer}</h3>
          </div>
          <video width="640" height="360" controls>
            <source src={video.path} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
      ))}
    </div>
  );
};

export default VideoDisplay;
