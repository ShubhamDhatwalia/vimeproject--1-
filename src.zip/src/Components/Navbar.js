
import { Link } from 'react-router-dom';
import { FaRegBell } from "react-icons/fa";
const Navbar = () => {
 

  return (
    <nav className="bg-white shadow shadow-gray-900 p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <Link to="/" className="text-black mr-4">
            Vimeo
          </Link>
          <input
            type="text"
            placeholder="Search"
            className="p-2 rounded  p-2 px-16 rounded-full border border-2 border-gray-400 text-black"
          />
        </div>
        <div className="flex items-center">
          <div className="mr-4">
            <button className="text-black">
              Upgrade
            </button>
          </div>
          <div className="mr-4">
            <button className="text-black">
              New Video
            </button>
          </div>
          <div className="mr-4">
            <button >
            <FaRegBell className="text-gray-600 text-xl" />
            </button>
          </div>
          <div>
            <img
              src="userprofile.jpg"
              alt="User Profile"
              className="w-8 h-8 rounded-full"
            />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
