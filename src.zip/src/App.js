import logo from './logo.svg';
import './App.css';
import { BrowserRouter } from 'react-router-dom';
import Navbar from './Components/Navbar';
import Sidebar from './Components/Sidebar';
import { useState } from 'react';




function App() {
 
  return (
    <>
    <BrowserRouter>
     <Navbar/>
     <Sidebar/>

     </BrowserRouter>
    </>
  );
}

export default App;





